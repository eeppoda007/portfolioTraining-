//
//  LifeGoalViewController.swift
//  Receiving Data
//
//  Created by Full Sail University
//  Copyright © 2019 Full Sail University. All rights reserved.
//

import UIKit

class LifeGoalViewController: UIViewController {
  
  @IBOutlet weak var textField: UITextField!
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    // Do any additional setup after loading the view.
  }
  
  
    @IBAction func goBack(sender: UIButton) {
        dismiss(animated: true, completion: nil)
  }
  
}
