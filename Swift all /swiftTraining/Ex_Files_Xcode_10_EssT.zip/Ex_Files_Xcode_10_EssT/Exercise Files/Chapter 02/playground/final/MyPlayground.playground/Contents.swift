import Cocoa

var str = "Hello, playground"
str = "updated string"

var a = [0,1,2,3,4,5,6]
var num = 0
for i in a {
    num += i
}
num
