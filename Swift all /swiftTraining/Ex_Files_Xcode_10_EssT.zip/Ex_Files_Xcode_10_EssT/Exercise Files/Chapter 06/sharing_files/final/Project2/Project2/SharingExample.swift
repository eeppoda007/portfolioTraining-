//
//  SharingExample.swift
//  Project2
//
//  Created by Todd Perkins on 12/13/18.
//  Copyright © 2018 Todd Perkins. All rights reserved.
//

import Cocoa

class SharingExample: NSObject {
    let prop = "example"
}
